package crl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAKey;
import java.security.interfaces.RSAPrivateKey;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509v2CRLBuilder;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import model.RevocationReason;

public interface CertificateRevocationList {
	
	public static void newCertificateRevocationList(X509Certificate certificate, PrivateKey privateKey, String alias) { 
		try { 
			@SuppressWarnings("deprecation")
			X509v2CRLBuilder crlBuilder = new X509v2CRLBuilder(new X500Name(PrincipalUtil.getIssuerX509Principal(certificate).getName()), Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			System.out.println("Privatni kljuc:");
			System.out.println(((RSAKey) privateKey).getModulus());
			System.out.println(((RSAPrivateKey) privateKey).getPrivateExponent());
			ContentSigner signer = new JcaContentSignerBuilder("SHA256WithRSAEncryption").setProvider("BC").build(privateKey);
			X509CRLHolder crl = crlBuilder.build(signer); 
		 
			File file = new File("./data/crl/" + alias + ".crl"); 
			FileOutputStream fos = null; 
			try { 
				fos = new FileOutputStream(file); 
					fos.write(crl.getEncoded()); 
					fos.flush(); 
					fos.close(); 
			} finally { 
				if (fos != null) { 
					fos.close(); 
				}  
			} 
		} catch (Exception e) { 
			throw new RuntimeException("Failed to create new certificate revocation list " + alias +".crl", e); 
		} 
	}
	
	public static boolean revoke(X509Certificate cert, PrivateKey caPrivateKey, String alias, RevocationReason reason) { 
		try { 
		   @SuppressWarnings("deprecation")
		X500Name issuerDN = new X500Name(PrincipalUtil.getIssuerX509Principal(cert).getName()); 
		X509v2CRLBuilder crlBuilder = new X509v2CRLBuilder(issuerDN, Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()));
		File f = new File("./data/crl/" + alias + ".crl");
		if(f.exists() && !f.isDirectory()) { 
		    byte [] data = FileUtils.readFileToByteArray(f);     
		    X509CRLHolder crl = new X509CRLHolder(data); 
		    crlBuilder.addCRL(crl); 
		} 
		crlBuilder.addCRLEntry(cert.getSerialNumber(), Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()), reason.ordinal()); 
		    
		// build and sign CRL with CA private key 
		System.out.println("Privatni kljuc:");
		System.out.println(((RSAKey) caPrivateKey).getModulus());
		System.out.println(((RSAPrivateKey) caPrivateKey).getPrivateExponent());
		Security.addProvider(new BouncyCastleProvider());
		ContentSigner signer = new JcaContentSignerBuilder("SHA256WithRSAEncryption").setProvider("BC").build(caPrivateKey); 
		X509CRLHolder crl = crlBuilder.build(signer); 
		    
		File tmpFile = new File("./data/crl/" + alias + ".tmp"); 
		FileOutputStream fos = null; 
		try { 
		    fos = new FileOutputStream(tmpFile); 
		    fos.write(crl.getEncoded()); 
		    fos.flush(); 
		    fos.close();
		    File file = new File("./data/crl/" + alias + ".crl");
		    if (file.exists()) { 
		    	file.delete(); 
		    } 
		    tmpFile.renameTo(file); 
		     
		} finally { 
		    if (fos != null) { 
		    	fos.close(); 
		    } 
		    if (tmpFile.exists()) { 
		    	tmpFile.delete(); 
		    } 
		}  
			return true; 
		} catch (Exception e) { 
			 e.printStackTrace();
		} 
		  return false; 
	}
	
	public static boolean isRevoked(BigInteger serialNumber, File caRevocationList) { 
		if (!caRevocationList.exists()) { 
			return false; 
		} 
		InputStream inStream = null; 
		try { 
			inStream = new FileInputStream(caRevocationList); 
			CertificateFactory cf = CertificateFactory.getInstance("X.509"); 
			X509CRL crl = (X509CRL)cf.generateCRL(inStream); 
			//return crl.isRevoked(cert);
			if(crl.getRevokedCertificate(serialNumber)!=null)
				return true;
			else
				return false;
		  	} catch (Exception e) { 
		  		e.printStackTrace(); 
		  	} finally { 
		  		if (inStream != null) { 
		    try { 
		    	inStream.close(); 
		    } catch (Exception e) {
		    	e.printStackTrace();
		    } 
		  	} 
		 } 
		  	return false; 
		 }
}

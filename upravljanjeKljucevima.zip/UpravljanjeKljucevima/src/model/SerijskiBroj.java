package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerijskiBroj {

	private Long sn;
	private static SerijskiBroj serijskiBroj = null;
	
	private SerijskiBroj() {
		sn = (long) 0;
	}
	
	public static SerijskiBroj getInstance() {
		if(serijskiBroj == null) {
			serijskiBroj = new SerijskiBroj();
			serijskiBroj.load();
		}
		return serijskiBroj;
	}
	
	public Long getNextSerijskiBroj() {
		sn++;
		save();
		return sn;
	}

	public void save(){
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./data/serijskiBroj.dat"));
			out.writeObject(this.sn);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void load()  {
		try {
			File file = new File("./data/serijskiBroj.dat");
			if (file.exists()) {
				ObjectInputStream in = new ObjectInputStream(new FileInputStream("./data/serijskiBroj.dat"));
				this.sn = (Long)in.readObject();
				in.close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}

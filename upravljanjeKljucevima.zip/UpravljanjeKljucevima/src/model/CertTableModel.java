package model;

import javax.swing.table.AbstractTableModel;

@SuppressWarnings("serial")
public class CertTableModel extends AbstractTableModel {
	
	private String[] columnNames ;
    private CertTable certTable;
    
    public CertTableModel(String[] columnNames, CertTable certTable) {
    	this.columnNames = columnNames;
    	this.certTable = certTable;
   
    }

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return certTable.getRowCount();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return certTable.getValueAt(rowIndex, columnIndex);
	}

	public String getColumnName(int col) {
        return columnNames[col];
    }
	
	public String toString(){
		return "a";
	}
}

package model;

public enum Validity {
	ONE_YEAR,
	TWO_YEARS,
	THREE_YEARS,
	FOUR_YEARS,
	FIVE_YEARS;
	
	@Override
	public String toString() {
		switch(this) {
	    	case ONE_YEAR: return "1 year";
	    	case TWO_YEARS: return "2 years";
	    	case THREE_YEARS: return "3 years";
	    	case FOUR_YEARS: return "4 years";
	    	case FIVE_YEARS: return "5 years";
	    	default: throw new IllegalArgumentException();
	    }
	}
	
	public Integer toInteger() {
		switch(this) {
    	case ONE_YEAR: return 1;
    	case TWO_YEARS: return 2;
    	case THREE_YEARS: return 3;
    	case FOUR_YEARS: return 4;
    	case FIVE_YEARS: return 5;
    	default: throw new IllegalArgumentException();
    }
	}
}

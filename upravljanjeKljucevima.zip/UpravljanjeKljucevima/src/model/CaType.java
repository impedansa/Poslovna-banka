package model;

public enum CaType {
	ROOT,
	INTERMEDIATE,
	END_ENTITY;
	
	@Override
	public String toString() {
		switch(this) {
	    	case ROOT: return "Root";
	    	case INTERMEDIATE: return "Intermediate";
	    	case END_ENTITY: return "End-entity";
	    	default: throw new IllegalArgumentException();
	    }
	}
}

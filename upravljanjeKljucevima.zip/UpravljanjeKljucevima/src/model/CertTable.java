package model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class CertTable{
	
	private HashMap<BigInteger, Cert> map = new HashMap<BigInteger, Cert>();
	
	public void addCert(Cert novi)  {
		map.put(novi.getId(), novi);
	}
	
	public void removeCert(Cert stari)   {
		 map.remove(stari.getId());
	}

	public int getRowCount() {
		return map.size();
	}
	
	public Cert getCert(String certificate){
		Cert a=null;
		for (Entry<BigInteger, Cert> entry : map.entrySet()) {
		    if(entry.getValue().getIssuedTo().equals(certificate)){
		    	a=entry.getValue();
		        return a;
		    }
		} 
		 return a;
	}
	

	public HashMap<BigInteger, Cert> getMap() {
		return map;
	}

	public void setMap(HashMap<BigInteger, Cert> mapaKS) {
		this.map = mapaKS;
	}
	
	public void setNew(){
		map = new HashMap<BigInteger, Cert>();
	}
	
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		ArrayList<Cert> keySert = new ArrayList<Cert>(map.values());
		switch(columnIndex){
			case 0: return keySert.get(rowIndex).getId();
			case 1: return keySert.get(rowIndex).getGivenName();
			case 2: return keySert.get(rowIndex).getIssuedTo();
			case 3: return keySert.get(rowIndex).getIssuedBy();
			case 4: return keySert.get(rowIndex).getStartDate();
			case 5: return keySert.get(rowIndex).getEndDate();
			case 6: return keySert.get(rowIndex).getCaType();
			case 7: {
				if(keySert.get(rowIndex).isValid())
					return "Yes";
				else
					return "No";
			}
		}
		return "";
	}
	
	public String getCommonName(BigInteger id){
		return map.get(id).getIssuedTo();
	}
	
	public String getRootAlias(){
		for (Entry<BigInteger, Cert> entry : map.entrySet()) {
		    if(entry.getValue().getCaType()==CaType.ROOT){
		        return entry.getValue().getIssuedTo();
		    }
		} 
		return null;
	}
}

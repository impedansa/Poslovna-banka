package model;

import java.math.BigInteger;
import java.util.Date;

public class Cert {
	
	private BigInteger id;
	private String givenName;
	private String issuedTo;
	private String issuedBy;
	private Date startDate;
	private Date endDate;
	private CaType caType;
	private Boolean validity;
	private Boolean revokeAllowed;
	
	public Cert() {
	}

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}
	
	public String getGivenName(){
		return givenName;
	}
	
	public void setGivenName(String givenName){
		this.givenName = givenName;
	}

	public String getIssuedTo() {
		return issuedTo;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String organisationName) {
		this.issuedBy = organisationName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public CaType getCaType(){
		return caType;
	}
	
	public void setCaType(CaType caType){
		this.caType = caType;
	}
	
	public Boolean isValid(){
		return validity;
	}
	
	public void setValidity(Boolean validity){
		this.validity = validity;
	}
	
	public Boolean isRevokeAllowed(){
		return revokeAllowed;
	}
	
	public void setRevokeAllowed(Boolean revokeAllowed){
		this.revokeAllowed = revokeAllowed;
	}
}

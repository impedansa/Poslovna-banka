package model;

public enum TipDijaloga {
	OPEN_KEYSTORE,
	GENERATE_INTERMEDIATE,
	GENERATE_END_ENTITY,
}

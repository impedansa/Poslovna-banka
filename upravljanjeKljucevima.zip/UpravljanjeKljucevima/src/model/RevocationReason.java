package model;

public enum RevocationReason { 
 
   unspecified, keyCompromise, caCompromise, affiliationChanged, superseded, 
   cessationOfOperation, certificateHold, unused, removeFromCRL, privilegeWithdrawn, 
   ACompromise; 
    
   public static RevocationReason [] reasons = { 
     unspecified, keyCompromise, caCompromise,  
     affiliationChanged, superseded, cessationOfOperation,  
     privilegeWithdrawn }; 
    
   @Override 
   public String toString() { 
    return name() +  " (" + ordinal() + ")"; 
   } 
 }
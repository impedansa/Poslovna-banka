package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import javax.swing.JDialog;
import javax.swing.JFileChooser;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import crl.CertificateRevocationList;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreWriter;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;

@SuppressWarnings("serial")
public class DialogImportCertificate extends JDialog {
	private JTextField tfImportLocation;
	private JTextField tfPrivateKeyLocation;
	private JRadioButton rbExisting;
	private JRadioButton rbNew;
	JLabel lblAlias;
	private JComboBox<String> cbAlias = new JComboBox<String>();
	private JPasswordField pfPassword;
	private String alias;
	private Integer numIncPass = 0;
		
	private static DialogImportCertificate dialogImportCertificate;

	private DialogImportCertificate() {
		
		setTitle("Import certificate");
		setSize(400,250);
		setLocationRelativeTo(null);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {150, 150, 20};
		gridBagLayout.rowHeights = new int[] {30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblImportLocation = new JLabel("Certificate path");
		GridBagConstraints gbc_lblImportLocation = new GridBagConstraints();
		gbc_lblImportLocation.insets = new Insets(0, 0, 5, 5);
		gbc_lblImportLocation.gridx = 0;
		gbc_lblImportLocation.gridy = 0;
		getContentPane().add(lblImportLocation, gbc_lblImportLocation);
		
		tfImportLocation = new JTextField(System.getProperty("user.dir") + "\\data\\certificates");
		JPanel pnlImportLocation = new JPanel();
		tfImportLocation.setColumns(100);
		pnlImportLocation.setLayout(new BorderLayout());
		pnlImportLocation.add(tfImportLocation, BorderLayout.CENTER);
		JButton btnImportLocation = new JButton("...");
		pnlImportLocation.add(btnImportLocation, BorderLayout.EAST);
		
		btnImportLocation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fcImportLocation = new JFileChooser(tfImportLocation.getText());
				fcImportLocation.addChoosableFileFilter(new FileNameExtensionFilter("*.cer", "cer"));
				fcImportLocation.setAcceptAllFileFilterUsed(false);
				int returnValue = fcImportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfImportLocation.setText(fcImportLocation.getSelectedFile().getPath());
				}
			}
		});
		btnImportLocation.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				JFileChooser fcImportLocation = new JFileChooser(tfImportLocation.getText());
				fcImportLocation.addChoosableFileFilter(new FileNameExtensionFilter("*.cer", "cer"));
				fcImportLocation.setAcceptAllFileFilterUsed(false);
				int returnValue = fcImportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfImportLocation.setText(fcImportLocation.getSelectedFile().getPath());
				}
			}
			@Override
			public void keyReleased(KeyEvent e) {
			}
			@Override
			public void keyPressed(KeyEvent e) {	
			}
		});
		
		GridBagConstraints gbc_pnlImportLocation = new GridBagConstraints();
		gbc_pnlImportLocation.fill = GridBagConstraints.HORIZONTAL;
		gbc_pnlImportLocation.insets = new Insets(0, 0, 5, 0);
		gbc_pnlImportLocation.gridx = 1;
		gbc_pnlImportLocation.gridy = 0;
		getContentPane().add(pnlImportLocation, gbc_pnlImportLocation);
		tfImportLocation.setColumns(1);
		
		JLabel lblPrivateKeyLocation = new JLabel("Private key path");
		GridBagConstraints gbc_lblPrivateKeyLocation = new GridBagConstraints();
		gbc_lblPrivateKeyLocation.insets = new Insets(0, 0, 5, 5);
		gbc_lblPrivateKeyLocation.gridx = 0;
		gbc_lblPrivateKeyLocation.gridy = 1;
		getContentPane().add(lblPrivateKeyLocation, gbc_lblPrivateKeyLocation);
		
		tfPrivateKeyLocation = new JTextField(System.getProperty("user.dir") + "\\data\\certificates");
		JPanel pnlPrivateKeyLocation = new JPanel();
		tfPrivateKeyLocation.setColumns(100);
		pnlPrivateKeyLocation.setLayout(new BorderLayout());
		pnlPrivateKeyLocation.add(tfPrivateKeyLocation, BorderLayout.CENTER);
		JButton btnPrivateKeyLocation = new JButton("...");
		pnlPrivateKeyLocation.add(btnPrivateKeyLocation, BorderLayout.EAST);
		
		btnPrivateKeyLocation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fcImportLocation = new JFileChooser(tfPrivateKeyLocation.getText());
				fcImportLocation.addChoosableFileFilter(new FileNameExtensionFilter("*.pem", "pem"));
				fcImportLocation.setAcceptAllFileFilterUsed(false);
				int returnValue = fcImportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfPrivateKeyLocation.setText(fcImportLocation.getSelectedFile().getPath());
				}
			}
		});
		btnImportLocation.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				JFileChooser fcImportLocation = new JFileChooser(tfPrivateKeyLocation.getText());
				fcImportLocation.addChoosableFileFilter(new FileNameExtensionFilter("*.pem", "pem"));
				fcImportLocation.setAcceptAllFileFilterUsed(false);
				int returnValue = fcImportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfPrivateKeyLocation.setText(fcImportLocation.getSelectedFile().getPath());
				}
			}
			@Override
			public void keyReleased(KeyEvent e) {
			}
			@Override
			public void keyPressed(KeyEvent e) {	
			}
		});
		
		GridBagConstraints gbc_pnlPrivateKeyLocation = new GridBagConstraints();
		gbc_pnlPrivateKeyLocation.fill = GridBagConstraints.HORIZONTAL;
		gbc_pnlPrivateKeyLocation.insets = new Insets(0, 0, 5, 0);
		gbc_pnlPrivateKeyLocation.gridx = 1;
		gbc_pnlPrivateKeyLocation.gridy = 1;
		getContentPane().add(pnlPrivateKeyLocation, gbc_pnlPrivateKeyLocation);
		tfPrivateKeyLocation.setColumns(1);
		
		JLabel lblKeystoreType = new JLabel("Keystore type");
		GridBagConstraints gbc_lblKeystoreType = new GridBagConstraints();
		gbc_lblKeystoreType.insets = new Insets(0, 0, 5, 5);
		gbc_lblKeystoreType.gridx = 0;
		gbc_lblKeystoreType.gridy = 2;
		getContentPane().add(lblKeystoreType, gbc_lblKeystoreType);
		
		rbExisting = new JRadioButton("Existing");
		rbExisting.setSelected(true);
		rbNew = new JRadioButton("New");
		ButtonGroup group = new ButtonGroup();
		group.add(rbExisting);
		group.add(rbNew);
		JPanel pnlRadioButton = new JPanel();
		pnlRadioButton.setLayout(new BorderLayout());
		pnlRadioButton.add(rbExisting, BorderLayout.WEST);
		pnlRadioButton.add(rbNew, BorderLayout.CENTER);
		GridBagConstraints gbc_RadioButton = new GridBagConstraints();
		gbc_RadioButton.fill = GridBagConstraints.HORIZONTAL;
		gbc_RadioButton.insets = new Insets(0, 0, 5, 0);
		gbc_RadioButton.gridx = 1;
		gbc_RadioButton.gridy = 2;
		getContentPane().add(pnlRadioButton, gbc_RadioButton);
		
		rbExisting.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				lblAlias.setText("Existing keystore");
				rbExisting.setSelected(true);
				cbAlias.setEditable(false);
				cbAlias.removeAllItems();
				File folder = new File("data/keystores");
				File[] listOfFiles = folder.listFiles();
				for (int i = 0; i < listOfFiles.length; i++) {
					if (listOfFiles[i].isFile()) {
						String str = listOfFiles[i].getName();
				        cbAlias.addItem(str.substring(0, str.length()-4));
					}
				}
			}
		});
		
		rbNew.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				rbNew.setSelected(true);
				lblAlias.setText("New keystore");
				cbAlias.removeAllItems();
				cbAlias.setEditable(true);
			}
		});
		
		lblAlias = new JLabel("Existing keystore");
		GridBagConstraints gbc_lblAlias = new GridBagConstraints();
		gbc_lblAlias.insets = new Insets(0, 0, 5, 5);
		gbc_lblAlias.gridx = 0;
		gbc_lblAlias.gridy = 3;
		getContentPane().add(lblAlias, gbc_lblAlias);
		
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		GridBagConstraints gbc_tfAlias = new GridBagConstraints();
		gbc_tfAlias.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfAlias.insets = new Insets(0, 0, 5, 0);
		gbc_tfAlias.gridx = 1;
		gbc_tfAlias.gridy = 3;
		getContentPane().add(cbAlias, gbc_tfAlias);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 0;
		gbc_lblPassword.gridy = 4;
		getContentPane().add(lblPassword, gbc_lblPassword);
		
		pfPassword = new JPasswordField();
		GridBagConstraints gbc_tfPassword = new GridBagConstraints();
		gbc_tfPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfPassword.insets = new Insets(0, 0, 5, 0);
		gbc_tfPassword.gridx = 1;
		gbc_tfPassword.gridy = 4;
		getContentPane().add(pfPassword, gbc_tfPassword);
		pfPassword.setColumns(1);
		
		JButton btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 5;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 5;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				alias = (String) cbAlias.getSelectedItem();
				String passKeyS = new String(pfPassword.getPassword());
				
				KeyStoreWriter keyStoreWriter = new KeyStoreWriter();
				File f = new File("./data/keystores/" + alias + ".jks");
				if(f.exists() && !f.isDirectory()) { 
					keyStoreWriter.loadKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
				}
				else {
					keyStoreWriter.loadKeyStore(null, passKeyS.toCharArray());
				}
				
				
				Certificate cert;
				try {
					FileInputStream fis = new FileInputStream(tfImportLocation.getText());
					BufferedInputStream bis = new BufferedInputStream(fis);

					CertificateFactory cf = CertificateFactory.getInstance("X.509");

					//Cita sertifikat po sertifikat
					//Svaki certifikat je izmedju 
					//-----BEGIN CERTIFICATE-----, 
					//i
					//-----END CERTIFICATE-----. 
					while (bis.available() > 0) {
					    cert = cf.generateCertificate(bis);
					    //System.out.println(cert.toString());
					    
					    JcaX509CertificateHolder holder = new JcaX509CertificateHolder((X509Certificate) cert);
						PrivateKey privateKey = readPrivateKey(tfPrivateKeyLocation.getText());
						
						keyStoreWriter.write(IETFUtils.valueToString(holder.getSubject().getRDNs(BCStyle.GIVENNAME)[0].getFirst().getValue()),privateKey , passKeyS.toCharArray(), cert);
						keyStoreWriter.saveKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
						
						CertificateRevocationList.newCertificateRevocationList((X509Certificate)cert, privateKey, alias);
						
					}
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (CertificateException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				} 
				
				MainFrame.getInstance().getCertTable().setNew();
				
				KeyStoreReader ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e1) {
					if(numIncPass>=2)
						System.exit(DISPOSE_ON_CLOSE);
					pfPassword.setText("");
					pfPassword.setBackground(Color.RED);
					pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
					pfPassword.requestFocus();
					return;
				}
				
				numIncPass = 0;
		
				passKeyS = null;
				pfPassword.setText("");
				MainFrame.getInstance().setSelectedKeystore(alias);
				MainFrame.getInstance().setCbItemListener(false);
				MainFrame.getInstance().init();
				MainFrame.getInstance().setCbItemListener(true);
				
				pfPassword.setText("");
				alias = null;
				dispose();
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
	
	public static DialogImportCertificate getInstance(){
		if(dialogImportCertificate == null)
			dialogImportCertificate = new DialogImportCertificate();
		return dialogImportCertificate;
	}
	
	public void setAlias(String alias){
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		this.alias = alias;
		this.cbAlias.setSelectedItem(alias);
	}
	
	public void initializeFields() {
		pfPassword.setText("");
		pfPassword.setToolTipText("");
		pfPassword.setBackground(Color.WHITE);
	}
	
	public void setFocusPass(){
		this.pfPassword.requestFocus();
	}
	
	private PrivateKey readPrivateKey(String path) {
        Security.addProvider(new BouncyCastleProvider());
        KeyFactory factory = null;
        PrivateKey key = null;
        byte[] privateKeyFileBytes = null;

        try {
            privateKeyFileBytes = Files.readAllBytes(Paths.get(path));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String KeyString = new String(privateKeyFileBytes);
        //System.out.println(KeyString);
        //System.out.println("FORMATTED:");
        KeyString = KeyString.replaceAll("-----BEGIN RSA PRIVATE KEY-----", "");
        KeyString = KeyString.replaceAll("-----END RSA PRIVATE KEY-----", "");
        KeyString = KeyString.replaceAll("[\n\r]", "");
        KeyString = KeyString.trim();
        //System.out.println(KeyString);

        byte[] encoded = Base64.getDecoder().decode(KeyString);

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
        // X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
        try {
            factory = KeyFactory.getInstance("RSA");
            key = factory.generatePrivate(keySpec);
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return key;
    }
}
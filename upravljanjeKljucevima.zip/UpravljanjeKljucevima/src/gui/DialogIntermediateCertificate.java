package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Random;

import javax.swing.JDialog;
import javax.swing.JTextField;

import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import model.SerijskiBroj;
import model.Validity;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.certificates.CertificateGenerator;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.data.IssuerData;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.data.SubjectData;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreWriter;

import javax.swing.JLabel;
import java.awt.GridBagLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JComboBox;

@SuppressWarnings("serial")
public class DialogIntermediateCertificate extends JDialog {

	private JTextField tfCertificateAuthority;
	private JTextField tfCommonName;
	//private JTextField tfSurname;
	//private JTextField tfGivenName;
	private JTextField tfOrganisationName;
	private JTextField tfOrganisationUnit;
	private JTextField tfCountryCode;
	//private JTextField tfEmail;
	private JTextField tfUserID;
	private JComboBox<Validity> tfValidity;
	private JButton btnOk;
	private boolean commonNameFirst = true;
	//private boolean surnameFirst = true;
	//private boolean givenNameFirst = true;
	private boolean organisationNameFirst = true;
	private boolean organisationUnitFirst = true;
	private boolean countryCodeFirst = true;
	//private boolean emailFirst = true;
	//private boolean userIDFirst = true;
	
	private IssuerData issuerData;
	
	private String alias;
	private String passKeyS;
	
	private static DialogIntermediateCertificate dialogIntermediateCertificate;
	
	
	private DialogIntermediateCertificate(){
		
		Security.addProvider(new BouncyCastleProvider());
	
		setTitle("Intermediate certificate");
		setSize(500,350);
		setLocationRelativeTo(null);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{217, 217, 0};
		gridBagLayout.rowHeights = new int[] {20, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblCertificateAuthority = new JLabel("Certificate authority");
		GridBagConstraints gbc_lblCertificateAuthority = new GridBagConstraints();
		gbc_lblCertificateAuthority.insets = new Insets(0, 0, 5, 5);
		gbc_lblCertificateAuthority.gridx = 0;
		gbc_lblCertificateAuthority.gridy = 0;
		getContentPane().add(lblCertificateAuthority, gbc_lblCertificateAuthority);
		
		tfCertificateAuthority = new JTextField();
		tfCertificateAuthority.setEnabled(false);
		GridBagConstraints gbc_tfCertificateAuthority = new GridBagConstraints();
		gbc_tfCertificateAuthority.anchor = GridBagConstraints.WEST;
		gbc_tfCertificateAuthority.insets = new Insets(0, 0, 5, 0);
		gbc_tfCertificateAuthority.gridx = 1;
		gbc_tfCertificateAuthority.gridy = 0;
		getContentPane().add(tfCertificateAuthority, gbc_tfCertificateAuthority);
		tfCertificateAuthority.setColumns(10);
		
		JLabel lblCommonName = new JLabel("Common Name");
		GridBagConstraints gbc_lblCommonName = new GridBagConstraints();
		gbc_lblCommonName.insets = new Insets(0, 0, 5, 5);
		gbc_lblCommonName.gridx = 0;
		gbc_lblCommonName.gridy = 1;
		getContentPane().add(lblCommonName, gbc_lblCommonName);
		
		tfCommonName = new JTextField();
		GridBagConstraints gbc_tfCommonName = new GridBagConstraints();
		gbc_tfCommonName.anchor = GridBagConstraints.WEST;
		gbc_tfCommonName.insets = new Insets(0, 0, 5, 0);
		gbc_tfCommonName.gridx = 1;
		gbc_tfCommonName.gridy = 1;
		getContentPane().add(tfCommonName, gbc_tfCommonName);
		tfCommonName.setColumns(10);
		
		/*JLabel lblSurname = new JLabel("Surname");
		GridBagConstraints gbc_lblSurname = new GridBagConstraints();
		gbc_lblSurname.insets = new Insets(0, 0, 5, 5);
		gbc_lblSurname.gridx = 0;
		gbc_lblSurname.gridy = 2;
		getContentPane().add(lblSurname, gbc_lblSurname);
		
		tfSurname = new JTextField();
		GridBagConstraints gbc_tfSurname = new GridBagConstraints();
		gbc_tfSurname.insets = new Insets(0, 0, 5, 0);
		gbc_tfSurname.anchor = GridBagConstraints.WEST;
		gbc_tfSurname.gridx = 1;
		gbc_tfSurname.gridy = 2;
		getContentPane().add(tfSurname, gbc_tfSurname);
		tfSurname.setColumns(10);
		
		JLabel lblGivenName = new JLabel("Given name");
		GridBagConstraints gbc_lblGivenName = new GridBagConstraints();
		gbc_lblGivenName.insets = new Insets(0, 0, 5, 5);
		gbc_lblGivenName.gridx = 0;
		gbc_lblGivenName.gridy = 3;
		getContentPane().add(lblGivenName, gbc_lblGivenName);
		
		tfGivenName = new JTextField();
		GridBagConstraints gbc_tfGivenName = new GridBagConstraints();
		gbc_tfGivenName.insets = new Insets(0, 0, 5, 0);
		gbc_tfGivenName.anchor = GridBagConstraints.WEST;
		gbc_tfGivenName.gridx = 1;
		gbc_tfGivenName.gridy = 3;
		getContentPane().add(tfGivenName, gbc_tfGivenName);
		tfGivenName.setColumns(10);*/
		
		JLabel lblOrganisationName = new JLabel("Organisation name");
		GridBagConstraints gbc_lblOrganisationName = new GridBagConstraints();
		gbc_lblOrganisationName.insets = new Insets(0, 0, 5, 5);
		gbc_lblOrganisationName.gridx = 0;
		gbc_lblOrganisationName.gridy = 4;
		getContentPane().add(lblOrganisationName, gbc_lblOrganisationName);
		
		tfOrganisationName = new JTextField();
		GridBagConstraints gbc_tfOrganisationName = new GridBagConstraints();
		gbc_tfOrganisationName.insets = new Insets(0, 0, 5, 0);
		gbc_tfOrganisationName.anchor = GridBagConstraints.WEST;
		gbc_tfOrganisationName.gridx = 1;
		gbc_tfOrganisationName.gridy = 4;
		getContentPane().add(tfOrganisationName, gbc_tfOrganisationName);
		tfOrganisationName.setColumns(10);
		
		JLabel lblOrganisatinUnit = new JLabel("Organisatin unit");
		GridBagConstraints gbc_lblOrganisatinUnit = new GridBagConstraints();
		gbc_lblOrganisatinUnit.insets = new Insets(0, 0, 5, 5);
		gbc_lblOrganisatinUnit.gridx = 0;
		gbc_lblOrganisatinUnit.gridy = 5;
		getContentPane().add(lblOrganisatinUnit, gbc_lblOrganisatinUnit);
		
		tfOrganisationUnit = new JTextField();
		GridBagConstraints gbc_tfOrganisationUnit = new GridBagConstraints();
		gbc_tfOrganisationUnit.insets = new Insets(0, 0, 5, 0);
		gbc_tfOrganisationUnit.anchor = GridBagConstraints.WEST;
		gbc_tfOrganisationUnit.gridx = 1;
		gbc_tfOrganisationUnit.gridy = 5;
		getContentPane().add(tfOrganisationUnit, gbc_tfOrganisationUnit);
		tfOrganisationUnit.setColumns(10);
		
		JLabel lblCountryCode = new JLabel("Country code");
		GridBagConstraints gbc_lblCountryCode = new GridBagConstraints();
		gbc_lblCountryCode.insets = new Insets(0, 0, 5, 5);
		gbc_lblCountryCode.gridx = 0;
		gbc_lblCountryCode.gridy = 6;
		getContentPane().add(lblCountryCode, gbc_lblCountryCode);
		
		tfCountryCode = new JTextField();
		GridBagConstraints gbc_tfCountryCode = new GridBagConstraints();
		gbc_tfCountryCode.insets = new Insets(0, 0, 5, 0);
		gbc_tfCountryCode.anchor = GridBagConstraints.WEST;
		gbc_tfCountryCode.gridx = 1;
		gbc_tfCountryCode.gridy = 6;
		getContentPane().add(tfCountryCode, gbc_tfCountryCode);
		tfCountryCode.setColumns(10);
		
		/*JLabel lblEmail = new JLabel("E-mail");
		GridBagConstraints gbc_lblEmail = new GridBagConstraints();
		gbc_lblEmail.insets = new Insets(0, 0, 5, 5);
		gbc_lblEmail.gridx = 0;
		gbc_lblEmail.gridy = 7;
		getContentPane().add(lblEmail, gbc_lblEmail);
		
		tfEmail = new JTextField();
		GridBagConstraints gbc_tfEmail = new GridBagConstraints();
		gbc_tfEmail.insets = new Insets(0, 0, 5, 0);
		gbc_tfEmail.anchor = GridBagConstraints.WEST;
		gbc_tfEmail.gridx = 1;
		gbc_tfEmail.gridy = 7;
		getContentPane().add(tfEmail, gbc_tfEmail);
		tfEmail.setColumns(10);*/
		
		JLabel lblUserID = new JLabel("User ID");
		GridBagConstraints gbc_lblUserID = new GridBagConstraints();
		gbc_lblUserID.insets = new Insets(0, 0, 5, 5);
		gbc_lblUserID.gridx = 0;
		gbc_lblUserID.gridy = 8;
		getContentPane().add(lblUserID, gbc_lblUserID);
		
		tfUserID = new JTextField();
		tfUserID.setEnabled(false);
		GridBagConstraints gbc_tfUserID = new GridBagConstraints();
		gbc_tfUserID.insets = new Insets(0, 0, 5, 0);
		gbc_tfUserID.anchor = GridBagConstraints.WEST;
		gbc_tfUserID.gridx = 1;
		gbc_tfUserID.gridy = 8;
		getContentPane().add(tfUserID, gbc_tfUserID);
		tfUserID.setColumns(10);
		
		JLabel lblValidity = new JLabel("Validity");
		GridBagConstraints gbc_lblValidity = new GridBagConstraints();
		gbc_lblValidity.insets = new Insets(0, 0, 5, 5);
		gbc_lblValidity.gridx = 0;
		gbc_lblValidity.gridy = 9;
		getContentPane().add(lblValidity, gbc_lblValidity);
		
		tfValidity = new JComboBox<Validity>(Validity.values());
		GridBagConstraints gbc_tfValidity = new GridBagConstraints();
		gbc_tfValidity.anchor = GridBagConstraints.WEST;
		gbc_tfValidity.insets = new Insets(0, 0, 5, 0);
		gbc_tfValidity.gridx = 1;
		gbc_tfValidity.gridy = 9;
		getContentPane().add(tfValidity, gbc_tfValidity);
		
		btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 10;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 10;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					commonNameFirst = true;
					//surnameFirst = true;
					//givenNameFirst = true;
					organisationNameFirst = true;
					organisationUnitFirst = true;
					countryCodeFirst = true;
					//emailFirst = true;
					//userIDFirst = true;
					KeyPair keyPair = generateKeyPair();
					SubjectData subjectData = generateSubjectData(keyPair.getPublic(), tfCommonName.getText(), tfOrganisationName.getText(), tfOrganisationUnit.getText(), tfCountryCode.getText(), tfUserID.getText(), ((Validity)tfValidity.getSelectedItem()).toInteger());
					
					//Generise se sertifikat za subjekta, potpisan od strane issuer-a
					CertificateGenerator cg = new CertificateGenerator();
					File file = new File("./data/crl/" + alias + ".crl");
					X509Certificate cert = cg.generateCertificate(subjectData, issuerData, true, file.getAbsolutePath());
					
					System.out.println("\n===== Podaci o izdavacu sertifikata =====");
					System.out.println(cert.getIssuerX500Principal().getName());
					System.out.println("\n===== Podaci o vlasniku sertifikata =====");
					System.out.println(cert.getSubjectX500Principal().getName());
					System.out.println("\n===== Sertifikat =====");
					System.out.println("-------------------------------------------------------");
					System.out.println(cert);
					System.out.println("-------------------------------------------------------");
					
					KeyStoreWriter keyStoreWriter = new KeyStoreWriter();
					File f = new File("./data/keystores/" + alias + ".jks");
					if(f.exists() && !f.isDirectory()) { 
						keyStoreWriter.loadKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
					}
					else {
						keyStoreWriter.loadKeyStore(null, passKeyS.toCharArray());
					}				
					
					keyStoreWriter.write(tfCommonName.getText(), keyPair.getPrivate(), passKeyS.toCharArray(), cert);
					keyStoreWriter.saveKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
					
					MainFrame.getInstance().getCertTable().setNew();
					
					KeyStoreReader ksReader = new KeyStoreReader();
					try {
						ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
					passKeyS = null;
					MainFrame.getInstance().setSelectedKeystore(alias);
					MainFrame.getInstance().setCbItemListener(false);
					MainFrame.getInstance().init();
					MainFrame.getInstance().setCbItemListener(true);
					
					tfCertificateAuthority.setText("");
					tfCommonName.setText("");
					//tfSurname.setText("");
					//tfGivenName.setText("");
					tfOrganisationName.setText("");
					tfOrganisationUnit.setText("");
					tfCountryCode.setText("");
					//tfEmail.setText("");
					tfUserID.setText("");
					tfValidity.setSelectedIndex(0);
					
					dispose();
				}
			}
		});
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				commonNameFirst = true;
				//surnameFirst = true;
				//givenNameFirst = true;
				organisationNameFirst = true;
				organisationUnitFirst = true;
				countryCodeFirst = true;
				//emailFirst = true;
				//userIDFirst = true;
				
				KeyPair keyPair = generateKeyPair();
				SubjectData subjectData = generateSubjectData(keyPair.getPublic(), tfCommonName.getText(), tfOrganisationName.getText(), tfOrganisationUnit.getText(), tfCountryCode.getText(), tfUserID.getText(), ((Validity)tfValidity.getSelectedItem()).toInteger());
				
				//Generise se sertifikat za subjekta, potpisan od strane issuer-a
				CertificateGenerator cg = new CertificateGenerator();
				File file = new File("./data/crl/" + alias + ".crl");
				X509Certificate cert = cg.generateCertificate(subjectData, issuerData, true, file.getAbsolutePath());
				
				System.out.println("\n===== Podaci o izdavacu sertifikata =====");
				System.out.println(cert.getIssuerX500Principal().getName());
				System.out.println("\n===== Podaci o vlasniku sertifikata =====");
				System.out.println(cert.getSubjectX500Principal().getName());
				System.out.println("\n===== Sertifikat =====");
				System.out.println("-------------------------------------------------------");
				System.out.println(cert);
				System.out.println("-------------------------------------------------------");
				
				KeyStoreWriter keyStoreWriter = new KeyStoreWriter();
				File f = new File("./data/keystores/" + alias + ".jks");
				if(f.exists() && !f.isDirectory()) { 
					keyStoreWriter.loadKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
				}
				else {
					keyStoreWriter.loadKeyStore(null, passKeyS.toCharArray());
				}				
				
				keyStoreWriter.write(tfCommonName.getText(), keyPair.getPrivate(), passKeyS.toCharArray(), cert);
				keyStoreWriter.saveKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
				
				MainFrame.getInstance().getCertTable().setNew();
				
				KeyStoreReader ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				passKeyS = null;
				MainFrame.getInstance().setSelectedKeystore(alias);
				MainFrame.getInstance().setCbItemListener(false);
				MainFrame.getInstance().init();
				MainFrame.getInstance().setCbItemListener(true);
				
				tfCertificateAuthority.setText("");
				tfCommonName.setText("");
				//tfSurname.setText("");
				//tfGivenName.setText("");
				tfOrganisationName.setText("");
				tfOrganisationUnit.setText("");
				tfCountryCode.setText("");
				//tfEmail.setText("");
				tfUserID.setText("");
				tfValidity.setSelectedIndex(0);
				
				dispose();
			}
		});
		
		btnCancel.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					dispose();
					commonNameFirst = true;
					//surnameFirst = true;
					//givenNameFirst = true;
					organisationNameFirst = true;
					organisationUnitFirst = true;
					countryCodeFirst = true;
					//emailFirst = true;
					//userIDFirst = true;
				}
				
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				commonNameFirst = true;
				//surnameFirst = true;
				//givenNameFirst = true;
				organisationNameFirst = true;
				organisationUnitFirst = true;
				countryCodeFirst = true;
				//emailFirst = true;
				//userIDFirst = true;
				dispose();
			}
		});
		
		tfCommonName.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfCommonName.getText().length() > 2 ) {
					tfCommonName.setBackground(Color.WHITE);
					tfCommonName.setToolTipText("");
				}
				else {
					if(!commonNameFirst){
						tfCommonName.setBackground(Color.RED);
						tfCommonName.setToolTipText("Enter correct common name.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfCommonName.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				commonNameFirst = false;
				if(tfCommonName.getText().length() <= 2) {
					tfCommonName.setBackground(Color.RED);
					tfCommonName.setToolTipText("Enter correct common name.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});
		/*tfSurname.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfSurname.getText().length() > 2 ) {
					tfSurname.setBackground(Color.WHITE);
					tfSurname.setToolTipText("");
				}
				else {
					if(!surnameFirst) {
						tfSurname.setBackground(Color.RED);
						tfSurname.setToolTipText("Enter correct surname.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfSurname.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				surnameFirst = false;
				if(tfSurname.getText().length() <= 2) {
					tfSurname.setBackground(Color.RED);
					tfSurname.setToolTipText("Enter correct surname.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});
		tfGivenName.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfGivenName.getText().length() > 2 ) {
					tfGivenName.setBackground(Color.WHITE);
					tfGivenName.setToolTipText("");
				}
				else {
					if(!givenNameFirst){
						tfGivenName.setBackground(Color.RED);
						tfGivenName.setToolTipText("Enter correct given name.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfGivenName.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				givenNameFirst = false;
				if(tfGivenName.getText().length() <= 2) {
					tfGivenName.setBackground(Color.RED);
					tfGivenName.setToolTipText("Enter correct given name.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});*/
		tfOrganisationName.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfOrganisationName.getText().length() > 2 ) {
					tfOrganisationName.setBackground(Color.WHITE);
					tfOrganisationName.setToolTipText("");
				}
				else {
					if(!organisationNameFirst) {
						tfOrganisationName.setBackground(Color.RED);
						tfOrganisationName.setToolTipText("Enter correct organisation name.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfOrganisationName.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				organisationNameFirst = false;
				if(tfOrganisationName.getText().length() <= 2) {
					tfOrganisationName.setBackground(Color.RED);
					tfOrganisationName.setToolTipText("Enter correct organisation name.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});
		tfOrganisationUnit.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfOrganisationUnit.getText().length() > 2 ) {
					tfOrganisationUnit.setBackground(Color.WHITE);
					tfOrganisationUnit.setToolTipText("");
				}
				else {
					if(!organisationUnitFirst) {
						tfOrganisationUnit.setBackground(Color.RED);
						tfOrganisationUnit.setToolTipText("Enter correct organisation unit.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfOrganisationUnit.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				organisationUnitFirst = false;
				if(tfOrganisationUnit.getText().length() <= 2) {
					tfOrganisationUnit.setBackground(Color.RED);
					tfOrganisationUnit.setToolTipText("Enter correct organisation unit.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});
		tfCountryCode.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfCountryCode.getText().length() > 3)
					countryCodeFirst = false;
				if(tfCountryCode.getText().length() >= 2 && tfCountryCode.getText().length() <= 3) {
					tfCountryCode.setBackground(Color.WHITE);
					tfCountryCode.setToolTipText("");
				}
				else {
					if(!countryCodeFirst) {
						tfCountryCode.setBackground(Color.RED);
						tfCountryCode.setToolTipText("Enter correct country code.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfCountryCode.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				countryCodeFirst = false;
			}
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});
		/*tfEmail.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(isValidEmailAddress(tfEmail.getText())) {
					tfEmail.setBackground(Color.WHITE);
					tfEmail.setToolTipText("");
				}
				else {
					if(!emailFirst) {
						tfEmail.setBackground(Color.RED);
						tfEmail.setToolTipText("Enter correct E-mail.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfEmail.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				emailFirst = false;
				if(!isValidEmailAddress(tfEmail.getText())) {
					tfEmail.setBackground(Color.RED);
					tfEmail.setToolTipText("Enter correct E-mail.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});*/
		/*tfUserID.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				Validator();
				if(tfUserID.getText().length() > 2 ) {
					tfUserID.setBackground(Color.WHITE);
					tfUserID.setToolTipText("");
				}
				else {
					if(!userIDFirst){
						tfUserID.setBackground(Color.RED);
						tfUserID.setToolTipText("Enter correct user ID.");
					}
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		tfUserID.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				Validator();
				userIDFirst = false;
				if(tfUserID.getText().length() <= 2) {
					tfUserID.setBackground(Color.RED);
					tfUserID.setToolTipText("Enter correct user ID.");
				}
			}			
			@Override
			public void focusGained(FocusEvent e) {	
			}
		});*/
	}
	
	private KeyPair generateKeyPair() {
        try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA"); 
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
			keyGen.initialize(2048, random);
			return keyGen.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		}
        return null;
	}
	
	private SubjectData generateSubjectData(PublicKey publicKey, String commonName, String organizationName, String organizationUnit, String countryCode, String userID, Integer validity) {
				
		//Datumi od kad do kad vazi sertifikat
		LocalDate localDate = LocalDate.now();
		Date startDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date endDate = Date.from(localDate.plusYears(validity).atStartOfDay(ZoneId.systemDefault()).toInstant());
		
		//Serijski broj sertifikata
		BigInteger sn = new BigInteger(20, new Random(SerijskiBroj.getInstance().getNextSerijskiBroj()));
		//klasa X500NameBuilder pravi X500Name objekat koji predstavlja podatke o vlasniku
		X500NameBuilder builder = new X500NameBuilder(BCStyle.INSTANCE);
		builder.addRDN(BCStyle.CN, commonName);
		//builder.addRDN(BCStyle.SURNAME, surname);
		//builder.addRDN(BCStyle.GIVENNAME, givenName);
		builder.addRDN(BCStyle.O, organizationName);
		builder.addRDN(BCStyle.OU, organizationUnit);
		builder.addRDN(BCStyle.C, countryCode);
		//builder.addRDN(BCStyle.E, email);
		//UID (USER ID) je ID korisnika
		builder.addRDN(BCStyle.UID, userID);
		
		//Kreiraju se podaci za sertifikat, sto ukljucuje:
		// - javni kljuc koji se vezuje za sertifikat
		// - podatke o vlasniku
		// - serijski broj sertifikata
		// - od kada do kada vazi sertifikat
		return new SubjectData(publicKey, builder.build(), sn.toString(), startDate, endDate);
		
	}
	
	public static DialogIntermediateCertificate getInstance(){
		if(dialogIntermediateCertificate == null)
			dialogIntermediateCertificate = new DialogIntermediateCertificate();
		return dialogIntermediateCertificate;
	}
	
	public void setIssuerData(IssuerData issuerData){
		this.issuerData = issuerData;
		this.tfCertificateAuthority.setText(IETFUtils.valueToString(issuerData.getX500name().getRDNs(BCStyle.CN)[0].getFirst().getValue()));
	}
	
	public void setKeyStoreInfo(String alias, String passKeyS){
		this.alias = alias;
		this.passKeyS = passKeyS;
	}
	
	private void Validator(){
		if ( tfCommonName.getText().length() > 2 && tfOrganisationName.getText().length() > 2 && tfOrganisationUnit.getText().length() > 2 && tfCountryCode.getText().length() >= 2 && tfCountryCode.getText().length() <= 3 )
			btnOk.setEnabled(true);
		else
			btnOk.setEnabled(false);
	}
	
	public void initializeTextFields(){
		tfCommonName.setBackground(Color.WHITE);
		//tfSurname.setBackground(Color.WHITE);
		//tfGivenName.setBackground(Color.WHITE);
		tfOrganisationName.setBackground(Color.WHITE);
		tfOrganisationUnit.setBackground(Color.WHITE);
		tfCountryCode.setBackground(Color.WHITE);
		//tfEmail.setBackground(Color.WHITE);
		tfUserID.setBackground(Color.WHITE);
		
		tfCommonName.setText("");
		//tfSurname.setText("");
		//tfGivenName.setText("");
		tfOrganisationName.setText("");
		tfOrganisationUnit.setText("");
		tfCountryCode.setText("");
		//tfEmail.setText("");
		tfUserID.setText(new BigInteger(10, new Random(SerijskiBroj.getInstance().getNextSerijskiBroj())).toString());
		
		tfCommonName.setToolTipText("");
		//tfSurname.setToolTipText("");
		//tfGivenName.setToolTipText("");
		tfOrganisationName.setToolTipText("");
		tfOrganisationUnit.setToolTipText("");
		tfCountryCode.setToolTipText("");
		//tfEmail.setToolTipText("");
		tfUserID.setToolTipText("");
	}
	
	/*public boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
	}*/
}


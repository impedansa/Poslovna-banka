package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

import javax.swing.JDialog;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;

import model.TipDijaloga;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import javax.swing.JButton;

@SuppressWarnings("serial")
public class DialogAccessKeystore extends JDialog {
	private JTextField tfAlias;
	private JPasswordField pfPassword;
	private String alias;
	private static DialogAccessKeystore dialog;
	private TipDijaloga tipDijaloga;
	private String certName;
	private Integer numIncPass = 0;
	
	private DialogAccessKeystore() {
		
		setTitle("Access to keystore");
		setSize(300,150);
		setLocationRelativeTo(null);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {150, 150, 20};
		gridBagLayout.rowHeights = new int[] {30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblAlias = new JLabel("Alias");
		GridBagConstraints gbc_lblAlias = new GridBagConstraints();
		gbc_lblAlias.insets = new Insets(0, 0, 5, 5);
		gbc_lblAlias.gridx = 0;
		gbc_lblAlias.gridy = 0;
		getContentPane().add(lblAlias, gbc_lblAlias);
		
		tfAlias = new JTextField();
		tfAlias.setEditable(false);
		GridBagConstraints gbc_tfAlias = new GridBagConstraints();
		gbc_tfAlias.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfAlias.insets = new Insets(0, 0, 5, 0);
		gbc_tfAlias.gridx = 1;
		gbc_tfAlias.gridy = 0;
		getContentPane().add(tfAlias, gbc_tfAlias);
		tfAlias.setColumns(1);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 0;
		gbc_lblPassword.gridy = 1;
		getContentPane().add(lblPassword, gbc_lblPassword);
		
		pfPassword = new JPasswordField();
		GridBagConstraints gbc_tfPassword = new GridBagConstraints();
		gbc_tfPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfPassword.insets = new Insets(0, 0, 5, 0);
		gbc_tfPassword.gridx = 1;
		gbc_tfPassword.gridy = 1;
		getContentPane().add(pfPassword, gbc_tfPassword);
		pfPassword.setColumns(1);
		
		JButton btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 2;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 2;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					String passKeyS = new String(pfPassword.getPassword());
					if(tipDijaloga == TipDijaloga.OPEN_KEYSTORE){
						MainFrame.getInstance().getCertTable().setNew();
					
						KeyStoreReader ksReader = new KeyStoreReader();
						try {
							ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
						} catch (IOException e1) {
							if(numIncPass>=2)
								System.exit(DISPOSE_ON_CLOSE);
							pfPassword.setText("");
							pfPassword.setBackground(Color.RED);
							pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
							pfPassword.requestFocus();
							return;
						}
						numIncPass = 0;
						MainFrame.getInstance().init();
					}
					else if(tipDijaloga == TipDijaloga.GENERATE_INTERMEDIATE){
						KeyStoreReader ksReader = new KeyStoreReader();
						try {
							DialogIntermediateCertificate.getInstance().setIssuerData(ksReader.readIssuerFromStore("./data/keystores/" + alias + ".jks", certName, passKeyS.toCharArray(), passKeyS.toCharArray()));
						} catch (Exception e1) {
							if(numIncPass>=2)
								System.exit(DISPOSE_ON_CLOSE);
							pfPassword.setText("");
							pfPassword.setBackground(Color.RED);
							pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
							pfPassword.requestFocus();
							return;
						}
						numIncPass = 0;
						DialogIntermediateCertificate.getInstance().setKeyStoreInfo(alias, passKeyS);
						DialogIntermediateCertificate.getInstance().setVisible(true);
						DialogIntermediateCertificate.getInstance().initializeTextFields();
					}
					else {
						KeyStoreReader ksReader = new KeyStoreReader();
						try {
							DialogEndEntityCertificate.getInstance().setIssuerData(ksReader.readIssuerFromStore("./data/keystores/" + alias + ".jks", certName, passKeyS.toCharArray(), passKeyS.toCharArray()));
						} catch (IOException e1) {
							if(numIncPass>=2)
								System.exit(DISPOSE_ON_CLOSE);
							pfPassword.setText("");
							pfPassword.setBackground(Color.RED);
							pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
							pfPassword.requestFocus();
							return;
						}
						numIncPass = 0;
						DialogEndEntityCertificate.getInstance().setKeyStoreInfo(alias, passKeyS);
						DialogEndEntityCertificate.getInstance().setVisible(true);
						DialogEndEntityCertificate.getInstance().initializeTextFields();
					}
					passKeyS = null;
					pfPassword.setText("");
					dispose();
				}
				
			}
		});
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String passKeyS = new String(pfPassword.getPassword());
				if(tipDijaloga == TipDijaloga.OPEN_KEYSTORE){
					MainFrame.getInstance().getCertTable().setNew();
				
					KeyStoreReader ksReader = new KeyStoreReader();
					try {
						ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
					} catch (IOException e1) {
						if(numIncPass>=2)
							System.exit(DISPOSE_ON_CLOSE);
						pfPassword.setText("");
						pfPassword.setBackground(Color.RED);
						pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
						pfPassword.requestFocus();
						return;
					}
					numIncPass = 0;
					MainFrame.getInstance().init();
				}
				else if(tipDijaloga == TipDijaloga.GENERATE_INTERMEDIATE){
					KeyStoreReader ksReader = new KeyStoreReader();
					try {
						DialogIntermediateCertificate.getInstance().setIssuerData(ksReader.readIssuerFromStore("./data/keystores/" + alias + ".jks", certName, passKeyS.toCharArray(), passKeyS.toCharArray()));
					} catch (Exception e1) {
						if(numIncPass>=2)
							System.exit(DISPOSE_ON_CLOSE);
						pfPassword.setText("");
						pfPassword.setBackground(Color.RED);
						pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
						pfPassword.requestFocus();
						return;
					}
					numIncPass = 0;
					DialogIntermediateCertificate.getInstance().setKeyStoreInfo(alias, passKeyS);
					DialogIntermediateCertificate.getInstance().setVisible(true);
					DialogIntermediateCertificate.getInstance().initializeTextFields();
				}
				else {
					KeyStoreReader ksReader = new KeyStoreReader();
					try {
						DialogEndEntityCertificate.getInstance().setIssuerData(ksReader.readIssuerFromStore("./data/keystores/" + alias + ".jks", certName, passKeyS.toCharArray(), passKeyS.toCharArray()));
					} catch (IOException e1) {
						if(numIncPass>=2)
							System.exit(DISPOSE_ON_CLOSE);
						pfPassword.setText("");
						pfPassword.setBackground(Color.RED);
						pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
						pfPassword.requestFocus();
						return;
					}
					numIncPass = 0;
					DialogEndEntityCertificate.getInstance().setKeyStoreInfo(alias, passKeyS);
					DialogEndEntityCertificate.getInstance().setVisible(true);
					DialogEndEntityCertificate.getInstance().initializeTextFields();
				}
				passKeyS = null;
				pfPassword.setText("");
				dispose();
			}
		});
		
		btnCancel.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER)
					dispose();
				
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
	
	public void setAlias(String alias){
		this.alias = alias;
		tfAlias.setText(alias);
	}
	
	public static DialogAccessKeystore getIntance(){
		if(dialog == null)
			dialog = new DialogAccessKeystore();
		return dialog;
	}
	
	public void setTipDijaloga(TipDijaloga tipDijaloga){
		this.tipDijaloga = tipDijaloga;
	}
	
	public void setCertName(String certName){
		this.certName = certName;
	}

	public void setDefaultFocus() {
		pfPassword.requestFocus();
	}
	
	public void setPassFieldColor(){
		pfPassword.setBackground(Color.WHITE);
	}
	
}

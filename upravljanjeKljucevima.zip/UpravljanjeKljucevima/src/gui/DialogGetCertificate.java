package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.PrivateKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;

import javax.swing.JDialog;
import javax.swing.JFileChooser;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;

import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;

import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import rs.ac.uns.ftn.informatika.ib.util.Base64Utility;

import javax.swing.JButton;
import javax.swing.JComboBox;

@SuppressWarnings("serial")
public class DialogGetCertificate extends JDialog {
	private JTextField tfExportLocation;
	private JTextField tfCertificateSN;
	private JComboBox<String> cbAlias = new JComboBox<String>();
	private JPasswordField pfPassword;
	private String alias;
	private BigInteger certificateSN;
	private Integer numIncPass = 0;
	
	private static DialogGetCertificate dialogGetCertificate;

	private DialogGetCertificate() {
		
		setTitle("Export certificate");
		setSize(400,200);
		setLocationRelativeTo(null);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {150, 150, 20};
		gridBagLayout.rowHeights = new int[] {30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblExportLocation = new JLabel("Export location");
		GridBagConstraints gbc_lblExportLocation = new GridBagConstraints();
		gbc_lblExportLocation.insets = new Insets(0, 0, 5, 5);
		gbc_lblExportLocation.gridx = 0;
		gbc_lblExportLocation.gridy = 0;
		getContentPane().add(lblExportLocation, gbc_lblExportLocation);
		
		tfExportLocation = new JTextField(System.getProperty("user.dir") + "\\data\\certificates");
		JPanel pnlExportLocation = new JPanel();
		tfExportLocation.setColumns(100);
		pnlExportLocation.setLayout(new BorderLayout());
		pnlExportLocation.add(tfExportLocation, BorderLayout.CENTER);
		JButton btnExportLocation = new JButton("...");
		pnlExportLocation.add(btnExportLocation, BorderLayout.EAST);
		
		btnExportLocation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fcExportLocation = new JFileChooser(tfExportLocation.getText());
				fcExportLocation.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnValue = fcExportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfExportLocation.setText(fcExportLocation.getSelectedFile().getPath());
				}
			}
		});
		btnExportLocation.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				JFileChooser fcExportLocation = new JFileChooser(tfExportLocation.getText());
				fcExportLocation.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnValue = fcExportLocation.showOpenDialog(null);
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					tfExportLocation.setText(fcExportLocation.getSelectedFile().getPath());
				}
			}
			@Override
			public void keyReleased(KeyEvent e) {
			}
			@Override
			public void keyPressed(KeyEvent e) {	
			}
		});
		
		GridBagConstraints gbc_pnlExportLocation = new GridBagConstraints();
		gbc_pnlExportLocation.fill = GridBagConstraints.HORIZONTAL;
		gbc_pnlExportLocation.insets = new Insets(0, 0, 5, 0);
		gbc_pnlExportLocation.gridx = 1;
		gbc_pnlExportLocation.gridy = 0;
		getContentPane().add(pnlExportLocation, gbc_pnlExportLocation);
		tfExportLocation.setColumns(1);
		
		JLabel lblCertificateSN = new JLabel("Certificate SN");
		GridBagConstraints gbc_lblCertificateSN = new GridBagConstraints();
		gbc_lblCertificateSN.insets = new Insets(0, 0, 5, 5);
		gbc_lblCertificateSN.gridx = 0;
		gbc_lblCertificateSN.gridy = 1;
		getContentPane().add(lblCertificateSN, gbc_lblCertificateSN);
		
		tfCertificateSN = new JTextField();
		GridBagConstraints gbc_tfCertificateSN = new GridBagConstraints();
		gbc_tfCertificateSN.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfCertificateSN.insets = new Insets(0, 0, 5, 0);
		gbc_tfCertificateSN.gridx = 1;
		gbc_tfCertificateSN.gridy = 1;
		getContentPane().add(tfCertificateSN, gbc_tfCertificateSN);
		tfCertificateSN.setColumns(1);
		
		JLabel lblAlias = new JLabel("Alias");
		GridBagConstraints gbc_lblAlias = new GridBagConstraints();
		gbc_lblAlias.insets = new Insets(0, 0, 5, 5);
		gbc_lblAlias.gridx = 0;
		gbc_lblAlias.gridy = 2;
		getContentPane().add(lblAlias, gbc_lblAlias);
		
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		GridBagConstraints gbc_tfAlias = new GridBagConstraints();
		gbc_tfAlias.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfAlias.insets = new Insets(0, 0, 5, 0);
		gbc_tfAlias.gridx = 1;
		gbc_tfAlias.gridy = 2;
		getContentPane().add(cbAlias, gbc_tfAlias);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 0;
		gbc_lblPassword.gridy = 3;
		getContentPane().add(lblPassword, gbc_lblPassword);
		
		pfPassword = new JPasswordField();
		GridBagConstraints gbc_tfPassword = new GridBagConstraints();
		gbc_tfPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfPassword.insets = new Insets(0, 0, 5, 0);
		gbc_tfPassword.gridx = 1;
		gbc_tfPassword.gridy = 3;
		getContentPane().add(pfPassword, gbc_tfPassword);
		pfPassword.setColumns(1);
		
		JButton btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 4;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 4;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				certificateSN = new BigInteger(tfCertificateSN.getText().trim());
				alias = (String) cbAlias.getSelectedItem();
				String passKeyS = new String(pfPassword.getPassword());	
				
				KeyStoreReader ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e2) {
					if(numIncPass>=2)
						System.exit(DISPOSE_ON_CLOSE);
					pfPassword.setText("");
					pfPassword.setBackground(Color.RED);
					pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
					pfPassword.requestFocus();
					return;
				}
				
				numIncPass = 0;
				
				String commonName = MainFrame.getInstance().getCertTable().getCommonName(certificateSN);
				
				ksReader = new KeyStoreReader();
				X509Certificate certificate = (X509Certificate) ksReader.readCertificate("./data/keystores/" + alias + ".jks", passKeyS, commonName);
				
				try {
					File file = new File(tfExportLocation.getText().trim() + "\\test.txt");
					file.getParentFile().mkdirs();
					final FileOutputStream os = new FileOutputStream(tfExportLocation.getText().trim() + "\\" + commonName + ".cer");
					os.write("-----BEGIN CERTIFICATE-----\n".getBytes("US-ASCII"));
					os.write(Base64Utility.encode(certificate.getEncoded()).getBytes("US-ASCII"));
					os.write("-----END CERTIFICATE-----\n".getBytes("US-ASCII"));
					os.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CertificateEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				PrivateKey privateKey = ksReader.readPrivateKey("./data/keystores/" + alias + ".jks", passKeyS, commonName, passKeyS);
				PemObject pemObject = new PemObject("RSA PRIVATE KEY", privateKey.getEncoded());
				PemWriter pemWriter = null;
				
				try {
		            pemWriter = new PemWriter(new OutputStreamWriter(new FileOutputStream(tfExportLocation.getText().trim() + "\\" + commonName + ".pem")));
		            pemWriter.writeObject(pemObject);
		            pemWriter.close();
		        } catch (FileNotFoundException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        } catch (IOException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        }
		
				passKeyS = null;
				pfPassword.setText("");
				MainFrame.getInstance().setSelectedKeystore(alias);
				MainFrame.getInstance().setCbItemListener(false);
				MainFrame.getInstance().init();
				MainFrame.getInstance().setCbItemListener(true);
				
				pfPassword.setText("");
				alias = null;
				certificateSN = null;
				certificate = null;
								
				dispose();
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
	
	public static DialogGetCertificate getInstance(){
		if(dialogGetCertificate == null)
			dialogGetCertificate = new DialogGetCertificate();
		return dialogGetCertificate;
	}
	
	public void setAlias(String alias){
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		this.alias = alias;
		this.cbAlias.setSelectedItem(alias);
	}
	
	public void setCertificateSN(BigInteger certificateSN){
		this.certificateSN = certificateSN;
		this.tfCertificateSN.setText(certificateSN.toString());
	}
	
	public void setFocusPass(){
		this.pfPassword.requestFocus();
	}
	
	public void initializeFields() {
		pfPassword.setText("");
		pfPassword.setToolTipText("");
		pfPassword.setBackground(Color.WHITE);
	}
}

package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;

import javax.swing.JDialog;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;

import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;

import crl.CertificateRevocationList;
import model.RevocationReason;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.data.IssuerData;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import javax.swing.JButton;
import javax.swing.JComboBox;

@SuppressWarnings("serial")
public class DialogRevocation extends JDialog {
	private JTextField tfCertificateSN;
	private JComboBox<RevocationReason> cbRevocationReason;
	private JComboBox<String> cbAlias = new JComboBox<String>();
	private JPasswordField pfPassword;
	private String alias;
	private BigInteger certificateSN;
	private Integer numIncPass = 0;
	
	private static DialogRevocation dialogRevocation;

	private DialogRevocation() {
		
		setTitle("Revocation");
		setSize(300,200);
		setLocationRelativeTo(null);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {150, 150, 20};
		gridBagLayout.rowHeights = new int[] {30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblCertificateSN = new JLabel("Certificate SN");
		GridBagConstraints gbc_lblCertificateSN = new GridBagConstraints();
		gbc_lblCertificateSN.insets = new Insets(0, 0, 5, 5);
		gbc_lblCertificateSN.gridx = 0;
		gbc_lblCertificateSN.gridy = 0;
		getContentPane().add(lblCertificateSN, gbc_lblCertificateSN);
		
		tfCertificateSN = new JTextField();
		GridBagConstraints gbc_tfCertificateSN = new GridBagConstraints();
		gbc_tfCertificateSN.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfCertificateSN.insets = new Insets(0, 0, 5, 0);
		gbc_tfCertificateSN.gridx = 1;
		gbc_tfCertificateSN.gridy = 0;
		getContentPane().add(tfCertificateSN, gbc_tfCertificateSN);
		tfCertificateSN.setColumns(1);
		
		JLabel lblRevocationReason = new JLabel("Revocation Reason");
		GridBagConstraints gbc_lblRevocationReason = new GridBagConstraints();
		gbc_lblRevocationReason.insets = new Insets(0, 0, 5, 5);
		gbc_lblRevocationReason.gridx = 0;
		gbc_lblRevocationReason.gridy = 1;
		getContentPane().add(lblRevocationReason, gbc_lblRevocationReason);
		
		cbRevocationReason = new JComboBox<RevocationReason>(RevocationReason.values());
		GridBagConstraints gbc_cbRevocationReason = new GridBagConstraints();
		gbc_cbRevocationReason.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbRevocationReason.insets = new Insets(0, 0, 5, 0);
		gbc_cbRevocationReason.gridx = 1;
		gbc_cbRevocationReason.gridy = 1;
		getContentPane().add(cbRevocationReason, gbc_cbRevocationReason);
		
		JLabel lblAlias = new JLabel("Alias");
		GridBagConstraints gbc_lblAlias = new GridBagConstraints();
		gbc_lblAlias.insets = new Insets(0, 0, 5, 5);
		gbc_lblAlias.gridx = 0;
		gbc_lblAlias.gridy = 2;
		getContentPane().add(lblAlias, gbc_lblAlias);
		
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		GridBagConstraints gbc_tfAlias = new GridBagConstraints();
		gbc_tfAlias.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfAlias.insets = new Insets(0, 0, 5, 0);
		gbc_tfAlias.gridx = 1;
		gbc_tfAlias.gridy = 2;
		getContentPane().add(cbAlias, gbc_tfAlias);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 0;
		gbc_lblPassword.gridy = 3;
		getContentPane().add(lblPassword, gbc_lblPassword);
		
		pfPassword = new JPasswordField();
		GridBagConstraints gbc_tfPassword = new GridBagConstraints();
		gbc_tfPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfPassword.insets = new Insets(0, 0, 5, 0);
		gbc_tfPassword.gridx = 1;
		gbc_tfPassword.gridy = 3;
		getContentPane().add(pfPassword, gbc_tfPassword);
		pfPassword.setColumns(1);
		
		JButton btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 4;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 4;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				certificateSN = new BigInteger(tfCertificateSN.getText().trim());
				alias = (String) cbAlias.getSelectedItem();
				String passKeyS = new String(pfPassword.getPassword());	
				
				//MainFrame.getInstance().getCertTable().setNew();
				
				KeyStoreReader ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e1) {
					if(numIncPass>=2)
						System.exit(DISPOSE_ON_CLOSE);
					pfPassword.setText("");
					pfPassword.setBackground(Color.RED);
					pfPassword.setToolTipText("Password incorrect, attempts remaining:" + (3 - ++numIncPass));
					pfPassword.requestFocus();
					return;
				}
				
				numIncPass = 0;
				
				String commonName = MainFrame.getInstance().getCertTable().getCommonName(certificateSN);
				
				ksReader = new KeyStoreReader();
				X509Certificate certificate = (X509Certificate) ksReader.readCertificate("./data/keystores/" + alias + ".jks", passKeyS, commonName);
				IssuerData issuer;
				@SuppressWarnings("unused")
				JcaX509CertificateHolder holder;
				
				try {
					holder = new JcaX509CertificateHolder(certificate);
					String issuerName = MainFrame.getInstance().getCertTable().getRootAlias();
				
					issuer = ksReader.readIssuerFromStore("./data/keystores/" + alias + ".jks", issuerName, passKeyS.toCharArray(), passKeyS.toCharArray());
					CertificateRevocationList.revoke(certificate, issuer.getPrivateKey(), alias, (RevocationReason) cbRevocationReason.getSelectedItem());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CertificateEncodingException e1){
					e1.printStackTrace();
				}
				//PrivateKey privateKey = ksReader.readPrivateKey("./data/keystores/" + alias + ".jks", passKeyS, givenName, passKeyS);
		
				MainFrame.getInstance().getCertTable().setNew();
				
				ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				passKeyS = null;
				pfPassword.setText("");
				MainFrame.getInstance().setSelectedKeystore(alias);
				MainFrame.getInstance().setCbItemListener(false);
				MainFrame.getInstance().init();
				MainFrame.getInstance().setCbItemListener(true);
				
				pfPassword.setText("");
				alias = null;
				certificateSN = null;
				certificate = null;
				issuer = null;
								
				dispose();
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
	
	public static DialogRevocation getInstance(){
		if(dialogRevocation == null)
			dialogRevocation = new DialogRevocation();
		return dialogRevocation;
	}
	
	public void setAlias(String alias){
		cbAlias.removeAllItems();
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbAlias.addItem(str.substring(0, str.length()-4));
			}
		}
		this.alias = alias;
		this.cbAlias.setSelectedItem(alias);
	}
	
	public void setCertificateSN(BigInteger certificateSN){
		this.certificateSN = certificateSN;
		this.tfCertificateSN.setText(certificateSN.toString());
	}
}

package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import javax.swing.JDialog;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;

import crl.CertificateRevocationList;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.certificates.CertificateGenerator;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.data.IssuerData;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.data.SubjectData;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreReader;
import rs.ac.uns.ftn.informatika.ib.crypto.primeri.pki.keystores.KeyStoreWriter;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class DialogCreateKeysstore extends JDialog {
	private JTextField tfAlias;
	private JPasswordField pfPassword;
	private SubjectData subjectData;
	private IssuerData issuerData;
	private PrivateKey privateKey;
	String pcommonname;
	
	private static DialogCreateKeysstore dialogCreateKeystore;

	private DialogCreateKeysstore() {
		
		setTitle("Create keystore");
		setLocationRelativeTo(null);
		setSize(300,150);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {150, 150, 20};
		gridBagLayout.rowHeights = new int[] {30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblAlias = new JLabel("Alias");
		GridBagConstraints gbc_lblAlias = new GridBagConstraints();
		gbc_lblAlias.insets = new Insets(0, 0, 5, 5);
		gbc_lblAlias.gridx = 0;
		gbc_lblAlias.gridy = 0;
		getContentPane().add(lblAlias, gbc_lblAlias);
		
		tfAlias = new JTextField();
		GridBagConstraints gbc_tfAlias = new GridBagConstraints();
		gbc_tfAlias.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfAlias.insets = new Insets(0, 0, 5, 0);
		gbc_tfAlias.gridx = 1;
		gbc_tfAlias.gridy = 0;
		getContentPane().add(tfAlias, gbc_tfAlias);
		tfAlias.setColumns(1);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 0;
		gbc_lblPassword.gridy = 1;
		getContentPane().add(lblPassword, gbc_lblPassword);
		
		pfPassword = new JPasswordField();
		GridBagConstraints gbc_tfPassword = new GridBagConstraints();
		gbc_tfPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_tfPassword.insets = new Insets(0, 0, 5, 0);
		gbc_tfPassword.gridx = 1;
		gbc_tfPassword.gridy = 1;
		getContentPane().add(pfPassword, gbc_tfPassword);
		pfPassword.setColumns(1);
		
		JButton btnOk = new JButton("OK");
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.gridy = 2;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.gridx = 1;
		gbc_btnCancel.gridy = 2;
		getContentPane().add(btnCancel, gbc_btnCancel);
		
		btnOk.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					String alias = tfAlias.getText().trim();
					String passKeyS = new String(pfPassword.getPassword());	
				
					KeyStoreWriter keyStoreWriter = new KeyStoreWriter();
					File f = new File("./data/keystores/" + alias + ".jks");
					if(f.exists() && !f.isDirectory()) { 
						keyStoreWriter.loadKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
					}
					else {
						keyStoreWriter.loadKeyStore(null, passKeyS.toCharArray());
					}
					
					//Generise se sertifikat za subjekta, potpisan od strane issuer-a
					CertificateGenerator cg = new CertificateGenerator();
					File file = new File("./data/crl/" + alias + ".crl");
					X509Certificate cert = cg.generateCertificate(subjectData, issuerData, true, file.getAbsolutePath());
					
					System.out.println("\n===== Podaci o izdavacu sertifikata =====");
					System.out.println(cert.getIssuerX500Principal().getName());
					System.out.println("\n===== Podaci o vlasniku sertifikata =====");
					System.out.println(cert.getSubjectX500Principal().getName());
					System.out.println("\n===== Sertifikat =====");
					System.out.println("-------------------------------------------------------");
					System.out.println(cert);
					System.out.println("-------------------------------------------------------");
					
					keyStoreWriter.write(pcommonname, privateKey, passKeyS.toCharArray(), cert);
					keyStoreWriter.saveKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
					
					MainFrame.getInstance().getCertTable().setNew();
					
					KeyStoreReader ksReader = new KeyStoreReader();
					try {
						ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					CertificateRevocationList.newCertificateRevocationList(cert, privateKey, alias);
			
					passKeyS = null;
					pfPassword.setText("");
					MainFrame.getInstance().setSelectedKeystore(alias);
					MainFrame.getInstance().setCbItemListener(false);
					MainFrame.getInstance().init();
					MainFrame.getInstance().setCbItemListener(true);
					
					tfAlias.setText("");;
					pfPassword.setText("");;
					subjectData = null;
					issuerData = null;
					privateKey = null;
					pcommonname = null;
					
					dispose();
				}
				
			}
		});
		
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String alias = tfAlias.getText().trim();
				String passKeyS = new String(pfPassword.getPassword());	
			
				KeyStoreWriter keyStoreWriter = new KeyStoreWriter();
				File f = new File("./data/keystores/" + alias + ".jks");
				if(f.exists() && !f.isDirectory()) { 
					keyStoreWriter.loadKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
				}
				else {
					keyStoreWriter.loadKeyStore(null, passKeyS.toCharArray());
				}
				
				//Generise se sertifikat za subjekta, potpisan od strane issuer-a
				CertificateGenerator cg = new CertificateGenerator();
				File file = new File("./data/crl/" + alias + ".crl");
				X509Certificate cert = cg.generateCertificate(subjectData, issuerData, true, file.getAbsolutePath());
				
				System.out.println("\n===== Podaci o izdavacu sertifikata =====");
				System.out.println(cert.getIssuerX500Principal().getName());
				System.out.println("\n===== Podaci o vlasniku sertifikata =====");
				System.out.println(cert.getSubjectX500Principal().getName());
				System.out.println("\n===== Sertifikat =====");
				System.out.println("-------------------------------------------------------");
				System.out.println(cert);
				System.out.println("-------------------------------------------------------");
				
				keyStoreWriter.write(pcommonname, privateKey, passKeyS.toCharArray(), cert);
				keyStoreWriter.saveKeyStore("./data/keystores/" + alias + ".jks", passKeyS.toCharArray());
				
				MainFrame.getInstance().getCertTable().setNew();
				
				KeyStoreReader ksReader = new KeyStoreReader();
				try {
					ksReader.readCertTable("./data/keystores/" + alias + ".jks", passKeyS, "./data/crl/" + alias + ".crl");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				CertificateRevocationList.newCertificateRevocationList(cert, privateKey, alias);
		
				passKeyS = null;
				pfPassword.setText("");
				MainFrame.getInstance().setSelectedKeystore(alias);
				MainFrame.getInstance().setCbItemListener(false);
				MainFrame.getInstance().init();
				MainFrame.getInstance().setCbItemListener(true);
				
				tfAlias.setText("");;
				pfPassword.setText("");;
				subjectData = null;
				issuerData = null;
				privateKey = null;
				pcommonname = null;
				
				dispose();
			}
		});
		
		btnCancel.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				dispose();
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
	
	public static DialogCreateKeysstore getInstance(){
		if(dialogCreateKeystore == null)
			dialogCreateKeystore = new DialogCreateKeysstore();
		return dialogCreateKeystore;
	}
	
	public void setParameters(SubjectData subjectData, IssuerData issuerData, PrivateKey privateKey, String pcommonname){
		this.subjectData = subjectData;
		this.issuerData = issuerData;
		this.privateKey = privateKey;
		this.pcommonname = pcommonname;
	}
}

package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.math.BigInteger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.CaType;
import model.CertTable;
import model.CertTableModel;
import model.TipDijaloga;

public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel toolbar = new JPanel();
	private JTable table;
	private CertTable certTable = new CertTable();
	protected CertTableModel tableModel;
	private static MainFrame mainFrame = null;
	private JComboBox<String> cbKeyStore = new JComboBox<String>();
	private String selectedKeystore = null;
	private boolean cbItemListener = true;
	private Integer selectedTableRow;
	
	private JButton generateRootCertificate = new JButton("Root certificate");
	private JButton generateIntermediateCertificate = new JButton("Intermediate certificate");
	private JButton generateEndEntityCertificate = new JButton("End-entity certificate");
	private JButton importCertificate = new JButton("Import certificate");
	private JButton getCertificate = new JButton("Export certificate");
	private JButton revocation = new JButton("Revocation");
	
	//DialogRootCertificate dialogRootCertificate;
	//DialogIntermediateCertificate dialogIntermediateCertificate;
	//DialogEndEntityCertificate dialogEndEntityCertificate;
	
	public static MainFrame getInstance() {
		if (mainFrame == null) {
			mainFrame = new MainFrame();
		}
		
		return mainFrame;
	}
	
	public void init() {
		setSize(1000,600);
		setLocationRelativeTo(null);
		setTitle("Upravljanje kljucevima");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		toolbar.setSize(800, 50);
		add(toolbar, BorderLayout.NORTH);
		toolbar.setVisible(true);
		
		generateRootCertificate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) { 
				DialogRootCertificate.getInstance().setVisible(true);
				DialogRootCertificate.getInstance().initializeTextFields();
				
			}
		});
		toolbar.add(generateRootCertificate);
		
		generateIntermediateCertificate.setEnabled(false);
		generateIntermediateCertificate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DialogAccessKeystore.getIntance().setTipDijaloga(TipDijaloga.GENERATE_INTERMEDIATE);
				DialogAccessKeystore.getIntance().setAlias(selectedKeystore);
				DialogAccessKeystore.getIntance().setCertName((String)tableModel.getValueAt(selectedTableRow, 2));
				DialogAccessKeystore.getIntance().setVisible(true);
				DialogAccessKeystore.getIntance().setDefaultFocus();
				DialogAccessKeystore.getIntance().setPassFieldColor();
			}
		});
		toolbar.add(generateIntermediateCertificate);
		
		generateEndEntityCertificate.setEnabled(false);
		generateEndEntityCertificate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DialogAccessKeystore.getIntance().setTipDijaloga(TipDijaloga.GENERATE_END_ENTITY);
				DialogAccessKeystore.getIntance().setAlias(selectedKeystore);
				DialogAccessKeystore.getIntance().setCertName((String)tableModel.getValueAt(selectedTableRow, 2));
				DialogAccessKeystore.getIntance().setVisible(true);	
				DialogAccessKeystore.getIntance().setDefaultFocus();
				DialogAccessKeystore.getIntance().setPassFieldColor();
			}
		});
		toolbar.add(generateEndEntityCertificate);
		
		importCertificate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DialogImportCertificate.getInstance().initializeFields();
				if(selectedKeystore != null) {
					DialogImportCertificate.getInstance().setAlias(selectedKeystore);
					DialogImportCertificate.getInstance().setFocusPass();
				}
				DialogImportCertificate.getInstance().setVisible(true);				
			}
		});
		toolbar.add(importCertificate);
		
		getCertificate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					DialogGetCertificate.getInstance().initializeFields();
				if(selectedKeystore != null)
					DialogGetCertificate.getInstance().setAlias(selectedKeystore);
				if(selectedTableRow!=null) {
					DialogGetCertificate.getInstance().setCertificateSN((BigInteger)tableModel.getValueAt(selectedTableRow, 0));
					DialogGetCertificate.getInstance().setFocusPass();
				}
				DialogGetCertificate.getInstance().setVisible(true);
			}
		});
		toolbar.add(getCertificate);
		
		revocation.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(selectedKeystore != null)
					DialogRevocation.getInstance().setAlias(selectedKeystore);
				if(selectedTableRow != null)
					DialogRevocation.getInstance().setCertificateSN((BigInteger)(tableModel.getValueAt(selectedTableRow, 0)));
				DialogRevocation.getInstance().setVisible(true);
			}
		});
		toolbar.add(revocation);
		
		cbKeyStore.removeAllItems();
		cbKeyStore.addItem("");
		File folder = new File("data/keystores");
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String str = listOfFiles[i].getName();
		        cbKeyStore.addItem(str.substring(0, str.length()-4));
			}
		}
		toolbar.add(cbKeyStore);
		
		cbKeyStore.setSelectedItem(selectedKeystore);
		
		cbKeyStore.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String alias = cbKeyStore.getSelectedItem().toString();
					if(alias!="" && cbItemListener){
						selectedKeystore = alias;
						DialogAccessKeystore.getIntance().setTipDijaloga(TipDijaloga.OPEN_KEYSTORE);
						DialogAccessKeystore.getIntance().setAlias(alias);
						DialogAccessKeystore.getIntance().setVisible(true);
						DialogAccessKeystore.getIntance().setDefaultFocus();
						DialogAccessKeystore.getIntance().setPassFieldColor();
					}
			    }
			}
		});
		
		String[] tableColumns = new String[8];
		tableColumns[0] = "ID";
		tableColumns[1] = "Given name";
		tableColumns[2] = "Issued to";
		tableColumns[3] = "Issued by";
		tableColumns[4] = "Valid from";
		tableColumns[5] = "Valid to";
		tableColumns[6] = "Certificate type";
		tableColumns[7] = "Is valid";
		tableModel = new CertTableModel(tableColumns, certTable);
		
		table = new JTable(tableModel);
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setPreferredWidth(130);
		table.getColumnModel().getColumn(3).setPreferredWidth(130);
		table.getColumnModel().getColumn(4).setPreferredWidth(195);
		table.getColumnModel().getColumn(5).setPreferredWidth(195);
		table.getColumnModel().getColumn(6).setPreferredWidth(130);
		table.getColumnModel().getColumn(7).setPreferredWidth(50);
		table.setAutoCreateRowSorter(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(table);
		
		add(scrollPane, BorderLayout.CENTER);
		
		ListSelectionModel model = table.getSelectionModel();
		model.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if(!model.isSelectionEmpty()){
					selectedTableRow = model.getMinSelectionIndex();
					System.out.println(tableModel.getValueAt(selectedTableRow, 7));
					if(tableModel.getValueAt(selectedTableRow, 6) != CaType.END_ENTITY && tableModel.getValueAt(selectedTableRow, 7).equals("Yes")){
						generateIntermediateCertificate.setEnabled(true);
						generateEndEntityCertificate.setEnabled(true);
					}
					else{
						generateIntermediateCertificate.setEnabled(false);
						generateEndEntityCertificate.setEnabled(false);
					}
					if(tableModel.getValueAt(selectedTableRow, 7).equals("Yes")){
						getCertificate.setEnabled(true);
						if(certTable.getCert((String)(tableModel.getValueAt(selectedTableRow, 2))).isRevokeAllowed())
							revocation.setEnabled(true);
						else
							revocation.setEnabled(false);
					} else {
						getCertificate.setEnabled(false);
						revocation.setEnabled(false);
					}
				}
				else {
					generateIntermediateCertificate.setEnabled(false);
					generateEndEntityCertificate.setEnabled(false);
					getCertificate.setEnabled(true);
					revocation.setEnabled(true);
				}
				
			}
		});
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		MainFrame.getInstance().init();
	}
	
	public CertTable getCertTable() {
		return certTable;
	}
	
	public void setSelectedKeystore(String selectedKeystore) {
		this.selectedKeystore = selectedKeystore;
	}
	
	public void setCbItemListener(boolean b){
		cbItemListener = b;
	}
	
}
